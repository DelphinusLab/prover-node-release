# Running the Prover Node from TAR Archive

Unpack the archive by running `tar -xvf prover_node_{UbuntuVersion}.tar` in the directory you wish to run the prover node from.

## Using TAR archive

### Config file

Ensure the `prover_config.json` file is modified with the correct configuration for the prover node.

Set the `server_url` to the URL of the REST server to fetch tasks from. Currently the server address is https://zkwasm-explorer.delphinuslab.com:8090

Set the `priv_key` to the private key of the prover node to be used for identification purposes.

For `whitelisted_users` field, add any user addresses that are allowed to submit tasks to the prover node.
An empty array will allow any user to submit tasks to the prover node.

Some monitoring parameters can be configured in the `system_warnings` field. The prover node will log a warning if any of the parameters exceed the configured warning level values after a Task is performed.

```
{
  "server_url": "http://localhost:8080",
  "priv_key": "PRIVATE_KEY",
  "big_file_timeout": 1800,
  "get_timeout": 300,
  "post_timeout": 300,
  "whitelisted_users": [],
  "system_warnings": {
    "disk_usage_warning_level": 80.0,
    "memory_usage_warning_level": 80.0,
    "gpu_memory_usage_warning_level": 80.0,
    "cpu_temp_warning_level": 75.0,
    "gpu_temp_warning_level": 75.0
  },
  "max_debug_log_size_to_rest_server": 4194304
}

```

### Environment

As the prover node requires GPU support, ensure that the correct NVIDIA driver version and CUDA version are installed on the machine as the service will not start if the required dependencies are not met.

As of the time of writing, the prover node requires CUDA 12.2
This can be checked with `nvidia-smi`.
